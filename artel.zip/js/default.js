$(document).ready(function() {
    $('.slider-banner').slick({
        dots: false,
        arrows: false,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 2000,
        fade: true,
        cssEase: 'linear'
      });
      $('.slider-regular').slick({
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 1,
        centerMode: true,
        centerPadding: '0px',
        autoplay: false,
        autoplaySpeed: 1400,
        focusOnSelect: true
      });
      $('.slider-comments').slick({
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 3,
        autoplay: true,
        autoplaySpeed: 1400,
        responsive: [
            {
              breakpoint: 600,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
              }
            }
          ]
      });
    $('.slider-text').slick({
        arrows: true,
        dots: true,
        fade: true,
        infinite: true,
        mobileFirst: true,
        asNavFor: '.slider-img'
    });
    $('.slider-img').slick({
        arrows: false,
        mobileFirst: true,
        dots: false,
        infinite: true,
        asNavFor: '.slider-text'
    });
    $('.slider-full').slick({
        arrows: true,
        dots: true,
        fade: true,
        infinite: true,
        mobileFirst: true
    });
    $('.has-children > a').on('click', function() {
        $(this).toggleClass('active-js');
    });
    $('.product-grid-left__slider').slick({
        arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1
    });
    $('.current-choice').on('click', function() {
        $(this).toggleClass('open-js');
    });
    $('.modal-switcher__item').on('click', function() {
        $(this).parent().find('.modal-switcher__item').removeClass('modal-switcher__item--active');
        $(this).addClass('modal-switcher__item--active');
    });
    $('.search-icon').on('click', function() {
        $('nav').addClass('nav-js');
        $(this).parent().addClass('search-js');
    });
    $('.search-arrow').on('click', function() {
        $('nav').removeClass('nav-js');
        $(this).parent().removeClass('search-js');
    });
    $('.responsive-menu').on('click', function(){
        $(this).next().slideToggle();
    });
    $('.modal-content-sub-menu__item').on('click', function(){
        $(this).parent().prev().removeClass('open-js');
    });
    $('.mobile-header__menu').on('click', function(){
        $('.mobile-menu').slideToggle();
    });
});
//thumbs
$(window).on('resize load', function(){
    var windowWidth = $(window).width();
    if (windowWidth <  768){
        $('.product-grid-left-thumbs').slick({
            slidesToShow: 4,
            slidesToScroll: 1,
            focusOnSelect: true,
            mobileFirst: true,
            swipeToSlide: true,
            arrows: false,
            dots: false,
            infinite: true,
            asNavFor: '.product-grid-left__slider'
        });
        $('.product-grid-left__slider').slick({
            mobileFirst: true,
            infinite: true,
            arrows: true,
            asNavFor: '.product-grid-left-thumbs'
        });
    }
    else if (windowWidth >= 768){
        $('.product-grid-left-thumbs__item').on('click', function() {
        var currentSlide = $('.product-grid-left-thumbs__item').index($(this));
        $('.product-grid-left__slider').slick('slickGoTo', currentSlide);
    });
    }
    $('#menuToggle').click( function(){
        $('.mobi-nav').toggleClass("active");
        $('body').toggleClass("overflow-hidden");
      });
});